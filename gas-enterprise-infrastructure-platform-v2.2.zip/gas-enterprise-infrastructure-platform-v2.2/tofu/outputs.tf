output "vms" {
  description = "Built VMs and their recorded addresses."
  value = merge(
    { for k, m in module.vms_hpv013 : k => m.summary },
    { for k, m in module.vms_hpv012 : k => m.summary },
  )
}
