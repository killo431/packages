variable "hyperv_user" {
  type        = string
  description = "Hyper-V provisioning account (svc-tofu-hyperv). From Keeper via TF_VAR_hyperv_user."
}

variable "hyperv_password" {
  type        = string
  sensitive   = true
  description = "Password for svc-tofu-hyperv. From Keeper via TF_VAR_hyperv_password. No default."
}

variable "state_passphrase" {
  # Not marked sensitive: OpenTofu evaluates it statically for the encryption block, where
  # sensitive variables are rejected from 1.9 on. It is only ever used as key material, never output.
  type        = string
  description = "State/plan encryption passphrase. From Keeper via TF_VAR_state_passphrase."

  validation {
    condition     = length(var.state_passphrase) >= 16
    error_message = "state_passphrase must be at least 16 characters (pbkdf2 key provider minimum)."
  }
}

variable "vm_names" {
  type        = set(string)
  default     = []
  description = "Subset of data/vms.yml to manage in this run. Empty = all."
}

variable "seed_dir" {
  type        = string
  default     = null
  description = "Folder holding <VM>-seed.iso from playbooks/30_build_seed_iso.yml. Default: ../build/seed."
}
