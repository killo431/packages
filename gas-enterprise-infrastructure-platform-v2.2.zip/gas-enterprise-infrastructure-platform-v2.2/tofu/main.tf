locals {
  data_vms   = yamldecode(file("${path.root}/../data/vms.yml"))
  data_hosts = yamldecode(file("${path.root}/../data/hyperv_hosts.yml")).hyperv_hosts
  data_media = yamldecode(file("${path.root}/../data/media.yml"))
  seed_dir   = coalesce(var.seed_dir, "${path.root}/../build/seed")

  vms = {
    for name, spec in local.data_vms.vms : name => spec
    if length(var.vm_names) == 0 || contains(var.vm_names, name)
  }
}

module "vms_hpv013" {
  source    = "./modules/ubuntu_vm"
  providers = { hyperv = hyperv.hpv013 }
  for_each  = { for k, v in local.vms : k => v if v.hyperv_host == "GAS-HPV013" }

  name          = each.key
  spec          = each.value
  host          = local.data_hosts["GAS-HPV013"]
  install_iso   = local.data_media.gas_media.ubuntu_2404_iso
  seed_iso_path = "${local.seed_dir}/${each.key}-seed.iso"
}

module "vms_hpv012" {
  source    = "./modules/ubuntu_vm"
  providers = { hyperv = hyperv.hpv012 }
  for_each  = { for k, v in local.vms : k => v if v.hyperv_host == "GAS-HPV012" }

  name          = each.key
  spec          = each.value
  host          = local.data_hosts["GAS-HPV012"]
  install_iso   = local.data_media.gas_media.ubuntu_2404_iso
  seed_iso_path = "${local.seed_dir}/${each.key}-seed.iso"
}
