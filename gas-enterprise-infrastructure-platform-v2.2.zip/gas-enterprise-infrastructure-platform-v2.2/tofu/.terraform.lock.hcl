# This file is maintained automatically by "tofu init".
# Manual edits may be lost in future updates.

provider "registry.opentofu.org/taliesins/hyperv" {
  version     = "1.2.1"
  constraints = "1.2.1"
  hashes = [
    "h1:hivsU1Xo1nRTP+6hTLOoZFejh71KbEuUhaio9Oj7uBo=",
  ]
}
