variable "name" {
  type = string
  validation {
    condition     = can(regex("^GAS-", var.name))
    error_message = "VM names carry the GAS- prefix."
  }
}

variable "spec" {
  description = "One entry from data/vms.yml."
  type = object({
    hyperv_host   = string
    ip            = string
    prefix_length = number
    gateway       = string
    vcpu          = number
    memory_gb     = number
    os_disk_gb    = number
  })
}

variable "host" {
  description = "One entry from data/hyperv_hosts.yml."
  type = object({
    fqdn              = string
    ip                = string
    vm_root           = string
    iso_dir           = string
    switch_name       = string
    vlan_id           = number
    winrm_cacert_path = string
  })
}

variable "install_iso" {
  type = string
}

variable "seed_iso_path" {
  type        = string
  description = "Local path on GAS-AUTOCTLR of the CIDATA seed ISO."
}
