terraform {
  required_providers {
    hyperv = {
      source = "taliesins/hyperv"
    }
  }
}

locals {
  vm_dir    = "${coalesce(var.host.vm_root, "UNSET")}\\${var.name}"
  os_disk   = "${local.vm_dir}\\${var.name}-os.vhdx"
  seed_dest = "${local.vm_dir}\\${var.name}-seed.iso"
  gib       = 1024 * 1024 * 1024
}

# Fails the plan with a readable message while any <FILL-IN> is still null.
resource "terraform_data" "inputs" {
  input = var.name

  lifecycle {
    precondition {
      condition     = var.spec.vcpu != null && var.spec.memory_gb != null && var.spec.os_disk_gb != null
      error_message = "${var.name}: vcpu / memory_gb / os_disk_gb are <FILL-IN> in data/vms.yml."
    }
    precondition {
      condition     = var.host.vm_root != null && var.host.iso_dir != null && var.host.switch_name != null
      error_message = "${var.spec.hyperv_host}: vm_root / iso_dir / switch_name are <FILL-IN> in data/hyperv_hosts.yml."
    }
    precondition {
      condition     = var.host.winrm_cacert_path != null
      error_message = "${var.spec.hyperv_host}: winrm_cacert_path is <FILL-IN>; certificate validation stays on."
    }
    precondition {
      condition     = fileexists(var.seed_iso_path)
      error_message = "${var.seed_iso_path} missing - run playbooks/30_build_seed_iso.yml first."
    }
  }
}

resource "hyperv_iso_image" "seed" {
  source_iso_file_path      = var.seed_iso_path
  source_iso_file_path_hash = filesha256(var.seed_iso_path)
  destination_iso_file_path = local.seed_dest
  volume_name               = "CIDATA"

  depends_on = [terraform_data.inputs]
}

resource "hyperv_vhd" "os" {
  path     = local.os_disk
  vhd_type = "Dynamic"
  size     = var.spec.os_disk_gb * local.gib

  depends_on = [terraform_data.inputs]
}

resource "hyperv_machine_instance" "vm" {
  name                   = var.name
  path                   = var.host.vm_root
  smart_paging_file_path = local.vm_dir
  snapshot_file_location = local.vm_dir
  generation             = 2
  processor_count        = var.spec.vcpu
  static_memory          = true
  memory_startup_bytes   = var.spec.memory_gb * local.gib
  checkpoint_type        = "Production"
  automatic_start_action = "StartIfRunning"
  automatic_stop_action  = "ShutDown"
  state                  = "Running"
  notes                  = "Managed by OpenTofu (gas platform repo). IP ${var.spec.ip}/${var.spec.prefix_length}."

  vm_firmware {
    enable_secure_boot   = "On"
    secure_boot_template = "MicrosoftUEFICertificateAuthority"

    # Empty disk fails first, so the installer boots from DVD; after install the disk wins (no reinstall loop).
    boot_order {
      boot_type           = "HardDiskDrive"
      controller_number   = 0
      controller_location = 0
    }
    boot_order {
      boot_type           = "DvdDrive"
      controller_number   = 0
      controller_location = 1
    }
  }

  hard_disk_drives {
    controller_type     = "Scsi"
    controller_number   = 0
    controller_location = 0
    path                = hyperv_vhd.os.path
  }

  dvd_drives {
    controller_number   = 0
    controller_location = 1
    path                = "${var.host.iso_dir}\\${var.install_iso}"
  }

  dvd_drives {
    controller_number   = 0
    controller_location = 2
    path                = hyperv_iso_image.seed.destination_iso_file_path
  }

  network_adaptors {
    name                = "eth0"
    switch_name         = var.host.switch_name
    vlan_access         = true
    vlan_id             = var.host.vlan_id
    dynamic_mac_address = true
    wait_for_ips        = false
  }

  integration_services = {
    "Guest Service Interface" = true
    "Heartbeat"               = true
    "Key-Value Pair Exchange" = true
    "Shutdown"                = true
    "Time Synchronization"    = true
    "VSS"                     = true
  }
}
