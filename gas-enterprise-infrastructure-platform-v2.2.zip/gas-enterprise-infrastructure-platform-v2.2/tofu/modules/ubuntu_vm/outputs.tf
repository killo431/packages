output "summary" {
  value = {
    name        = hyperv_machine_instance.vm.name
    hyperv_host = var.spec.hyperv_host
    ip          = "${var.spec.ip}/${var.spec.prefix_length}"
    os_disk     = hyperv_vhd.os.path
  }
}
