# One provider per Hyper-V host. NTLM over HTTPS 5986 with certificate validation ON
# (record: svc-tofu-hyperv already builds GAS-ZBX01 this way). insecure is never true.
provider "hyperv" {
  alias           = "hpv013"
  user            = var.hyperv_user
  password        = var.hyperv_password
  host            = local.data_hosts["GAS-HPV013"].fqdn
  tls_server_name = local.data_hosts["GAS-HPV013"].fqdn
  port            = 5986
  https           = true
  insecure        = false
  use_ntlm        = true
  cacert_path     = local.data_hosts["GAS-HPV013"].winrm_cacert_path
  timeout         = "60s"
}

provider "hyperv" {
  alias           = "hpv012"
  user            = var.hyperv_user
  password        = var.hyperv_password
  host            = local.data_hosts["GAS-HPV012"].fqdn
  tls_server_name = local.data_hosts["GAS-HPV012"].fqdn
  port            = 5986
  https           = true
  insecure        = false
  use_ntlm        = true
  cacert_path     = local.data_hosts["GAS-HPV012"].winrm_cacert_path
  timeout         = "60s"
}
