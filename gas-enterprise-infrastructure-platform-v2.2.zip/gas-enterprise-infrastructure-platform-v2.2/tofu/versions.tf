terraform {
  required_version = ">= 1.8.0"

  required_providers {
    hyperv = {
      source  = "taliesins/hyperv"
      version = "= 1.2.1"
    }
  }

  # Local state, encrypted at rest (record: encrypted local state). Plans are encrypted too.
  # Passphrase comes from Keeper via TF_VAR_state_passphrase (scripts/run.sh -> ksm exec).
  encryption {
    key_provider "pbkdf2" "gas" {
      passphrase = var.state_passphrase
    }
    method "aes_gcm" "gas" {
      keys = key_provider.pbkdf2.gas
    }
    state {
      method   = method.aes_gcm.gas
      enforced = true
    }
    plan {
      method   = method.aes_gcm.gas
      enforced = true
    }
  }
}
