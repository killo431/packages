# AGENTS.md - rules for any AI or automation working in this repo

1. Facts come from `data/*.yml` and the GAS facts record. Never invent hosts, IPs, VLAN IDs, ports, versions or sizes; leave `null` with a `<FILL-IN>` comment.
2. Run `scripts/validate.sh` after every change. A report is only "passed" if a real command produced it.
3. Changing playbooks require `--limit` and are run with `--check --diff` first. No daemons, schedulers or self-healing loops; alerts go Zabbix -> JSM and a human acts.
4. Secrets only via `scripts/run.sh` (`ksm exec`). No passwords, tokens or keys in files, defaults or fallbacks.
5. WinRM is HTTPS + Kerberos with certificate validation. No CredSSP, NTLM to WinRM, or `server_cert_validation: ignore`.
6. Hostnames carry the GAS- prefix. Show network/broadcast/usable for every CIDR.
7. One tool per layer: Ansible + OpenTofu on GAS-AUTOCTLR, Semaphore UI as runner (replaced AWX; no K3s), Zabbix, Graylog, NetBox, Keeper, Atera. New tools must name what they replace.
9. Keeper client configs never go in environment variables on endpoints or servers; use a keeper.ini locked to the owning account (endpoints: SYSTEM + Administrators).
10. Semaphore schedules only read-only templates (00, 10).
8. Every prod-affecting doc gets Production Impact and Rollback sections.
