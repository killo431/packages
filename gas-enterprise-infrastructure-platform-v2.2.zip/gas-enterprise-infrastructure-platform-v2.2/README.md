# GAS platform automation (v2, rebuilt from review)

Randy Derego - 2026-10-29
Runs on **GAS-AUTOCTLR** (172.17.6.26) only. Replaces the generated `gas-enterprise-infrastructure-platform` bundle; see `docs/REVIEW-FIXES.md` for what was fixed, rebuilt, or removed and why.

> **Production Impact.** Playbooks 20-70 and `tofu apply` change hosts. Every one of them refuses to run without `--limit`, and every one supports `--check --diff`. Preflight (00) and the WinRM audit (10) are read-only. Nothing in this repo touches DCs, SQL, IIS, firewalls or FMC, and nothing runs on its own (no daemon, no scheduler).

## What it does

| Step | File | Changes | Target |
|---|---|---|---|
| 00 | `playbooks/00_preflight.yml` | read-only | controller: secrets resolved, krb5 realm, DNS = recorded IP, 5986 open, `\\GAS-FIL004\ISO` and `\\GAS-FIL004\Packages` readable |
| 10 | `playbooks/10_winrm_audit.yml` | read-only | all Windows: CredSSP, listeners, cert expiry -> `reports/winrm_audit.csv` |
| 20 | `playbooks/20_stage_media.yml` | host disk | platform Hyper-V hosts: copy Ubuntu ISO from `\\GAS-FIL004\ISO` |
| 30 | `playbooks/30_build_seed_iso.yml` | controller files | autoinstall seed ISO per VM in `build/seed/` |
| tofu | `tofu/` | new VMs | GAS-NBX01 on GAS-HPV013, GAS-GLG01 on GAS-HPV012 (Gen 2, Secure Boot, VLAN 6, static IP) |
| 40 | `playbooks/40_zabbix_agent2_windows.yml` | agent service | Hyper-V hosts: Zabbix Agent 2 from `\\GAS-FIL004\Packages`, per-host PSK, Hyper-V LLD + checkpoint age |
| 50 | `playbooks/50_graylog_sidecar_windows.yml` | agent service | blocked until GAS-GLG01 is built |
| 60 | `playbooks/60_atera_agent_windows.yml` | agent service | new Windows servers missing Atera |
| 61 | `playbooks/61_edr_bitdefender_windows.yml` | EDR | blocked until X-12 (authoritative EDR) is decided |
| 70 | `playbooks/70_ssh_hardening_linux.yml` | sshd drop-in | built platform Linux VMs, key-only by default |
| 80 | `playbooks/80_netbox_seed.yml` | NetBox objects | blocked until GAS-NBX01 is rebuilt |
| Atera | `scripts/atera/Install-GasKsmEndpoint.ps1`, `Test-GasKsmEndpoint.ps1` | KSM CLI + locked keeper.ini | Windows endpoints, via Atera as SYSTEM (`docs/ksm-endpoint-design.md`) |

Runner: CLI via `scripts/run.sh`, or **Semaphore UI** on GAS-AUTOCTLR (replaces AWX; K3s no longer needed) - see `docs/semaphore.md`. Both use the same playbooks, inventory and Keeper-resolved environment.

Single sources of truth: `data/ipam.yml` (from the network data sheet PDF + record, math re-checked by `scripts/check_ipam.py`), `data/hyperv_hosts.yml`, `data/vms.yml`, `data/media.yml`. Tofu and Ansible both read these files; no IP is typed twice.

## Working in Cursor

Rules in `.cursor/rules/`, ignore list in `.cursorignore`, one-time setup and the meta prompt in `docs/cursor/SETUP-PROMPT.md`, per-workflow kickoff prompts in `docs/cursor/WORKFLOWS.md`, artifact templates in `docs/templates/`. Open the repo over Remote-SSH on GAS-AUTOCTLR.

## Prerequisites on GAS-AUTOCTLR (one time)

1. `sudo apt-get install -y krb5-user libkrb5-dev gcc python3-dev genisoimage smbclient`
2. `source ~/netops/.venv/bin/activate && pip install -r requirements.txt`
3. `ansible-galaxy collection install -r requirements.yml -p ./collections`
4. `/etc/krb5.conf` per `docs/krb5.conf.example`.
5. Trust each Hyper-V host's WinRM HTTPS cert on the controller (HPV013's is self-signed, valid to 2027-10-09): export it, convert to PEM, add to `/usr/local/share/ca-certificates/` + `update-ca-certificates`, and set `winrm_cacert_path` in `data/hyperv_hosts.yml`.
6. `cp env/keeper.env.example env/keeper.env` and fill the Keeper record UIDs (notation only, no values).
7. `svc-ansible-winrm`: local admin (or Remote Management Users + Hyper-V Administrators) on the Hyper-V hosts, and read on both shares (share + NTFS). `<FILL-IN>` confirm.
8. OpenTofu provider: `tofu -chdir=tofu init` (pins taliesins/hyperv 1.2.1, same as gas-platform-tofu).

## Run order

```bash
scripts/validate.sh                                               # offline lint, syntax, subnet math, tofu validate
scripts/run.sh ansible-playbook playbooks/00_preflight.yml
scripts/run.sh ansible-playbook playbooks/10_winrm_audit.yml
scripts/run.sh ansible-playbook playbooks/20_stage_media.yml --limit GAS-HPV013 --check --diff
scripts/run.sh ansible-playbook playbooks/20_stage_media.yml --limit GAS-HPV013
scripts/run.sh ansible-playbook playbooks/30_build_seed_iso.yml -e vm_names=GAS-NBX01 -e netadmin_pubkey_file=<FILL-IN>
scripts/run.sh tofu -chdir=tofu plan -var 'vm_names=["GAS-NBX01"]' -out=nbx01.tfplan
scripts/run.sh tofu -chdir=tofu apply nbx01.tfplan
scripts/run.sh ansible-playbook playbooks/40_zabbix_agent2_windows.yml --limit GAS-HPV013 -e zabbix_psk_phase=transition --check --diff
```

GAS-NBX01: the current VM of that name is polluted (record) and must be exported then removed before `apply`, or tofu fails on the name. Export first: `Export-VM -Name GAS-NBX01 -Path <FILL-IN>` on GAS-HPV013.

Ubuntu 24.04 may ask "Continue with autoinstall?" on the VM console when the seed comes from cloud-init. If it does, use the same answer/kernel-argument method that built GAS-ZBX01 in gas-platform-tofu.

## Rollback

| Step | Rollback |
|---|---|
| 20 | Delete the copied ISO from the host ISO folder. |
| tofu | `scripts/run.sh tofu -chdir=tofu destroy -var 'vm_names=["GAS-NBX01"]'` (removes VM, disks, seed ISO). Re-import the exported old VM if needed. |
| 40 | Zabbix host -> Encryption -> No encryption; on the host restore the `zabbix_agent2.conf.*~` backup and restart "Zabbix Agent 2". |
| 50 / 60 / 61 | Uninstall the agent; remove the device from the Graylog / Atera / GravityZone console. |
| 70 | Delete `/etc/ssh/sshd_config.d/10-gas.conf`, `systemctl reload ssh`. Auto-reverts if `sshd -t` fails. |
| 80 | NetBox changelog revert, or delete objects tagged `seed-ipam-yml`. |
| KSM endpoint | Uninstall KSM CLI, delete `C:\ProgramData\Keeper\ksm`, clear `KSM_INI_DIR`/`KSM_CACHE_DIR`, revoke the site's client device in Keeper. |
| Semaphore | `systemctl disable --now semaphore`, revoke its KSM client device; CLI path unaffected. |

## Relationship to gas-platform-tofu

That repo already built GAS-ZBX01 with encrypted local state. This `tofu/` keeps its own encrypted state for GAS-NBX01 / GAS-GLG01 only. Two states on one host is acceptable short-term; the module (`tofu/modules/ubuntu_vm`) is written to drop into gas-platform-tofu so there is one state per host. Do not declare the same VM in both.

## Windows VMs

Not built by tofu yet. `playbooks/templates/windows/autounattend.xml.j2` is fixed (valid XML, no AutoLogon) but Gen 2 Windows ISOs stop at "Press any key to boot from CD" without a no-prompt boot image, so an unattended path needs a rebuilt ISO on `\\GAS-FIL004\ISO` first (`<FILL-IN>` decision).

## Open items

See `docs/REVIEW-FIXES.md` -> Open items.
