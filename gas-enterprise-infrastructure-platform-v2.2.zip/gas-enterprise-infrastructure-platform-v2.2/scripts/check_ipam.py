#!/usr/bin/env python3
"""Recompute and verify every prefix in data/ipam.yml and every VM IP in data/vms.yml.
Fails on: invalid boundaries, wrong network/broadcast/usable values, gateways outside
their prefix, overlapping non-aggregate prefixes, VM IPs outside their prefix or on a gateway,
host ip_cidr that does not match its containing prefix."""
import ipaddress
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
errors = []
ipam = yaml.safe_load((ROOT / "data/ipam.yml").read_text())
vms = yaml.safe_load((ROOT / "data/vms.yml").read_text())["vms"]

nets = []
for p in ipam["ipam_prefixes"]:
    try:
        n = ipaddress.ip_network(p["prefix"], strict=True)
    except ValueError as e:
        errors.append(f"{p['prefix']}: invalid boundary ({e})")
        continue
    exp = {
        "network": str(n.network_address),
        "broadcast": str(n.broadcast_address),
        "first_usable": str(n.network_address + 1),
        "last_usable": str(n.broadcast_address - 1),
        "usable_hosts": n.num_addresses - 2,
    }
    for k, v in exp.items():
        if p.get(k) != v:
            errors.append(f"{p['prefix']}: {k} is {p.get(k)}, expected {v}")
    for g in (p.get("gateway"), p.get("gateway_standby")):
        if g and ipaddress.ip_address(g) not in n:
            errors.append(f"{p['prefix']}: gateway {g} outside prefix")
    if p["kind"] != "aggregate":
        nets.append((n, p))

for i, (a, pa) in enumerate(nets):
    for b, pb in nets[i + 1:]:
        if a.overlaps(b):
            errors.append(f"overlap: {a} ({pa['name']}) and {b} ({pb['name']})")

for h in ipam["ipam_hosts"]:
    ip = ipaddress.ip_address(h["ip"])
    holders = sorted((n for n, _ in nets if ip in n), key=lambda n: n.prefixlen, reverse=True)
    want = f"{ip}/{holders[0].prefixlen}" if holders else None
    if h.get("ip_cidr") != want:
        errors.append(f"host {h['name']}: ip_cidr {h.get('ip_cidr')} expected {want}")

for name, v in vms.items():
    net = ipaddress.ip_network(f"{v['ip']}/{v['prefix_length']}", strict=False)
    if ipaddress.ip_address(v["gateway"]) not in net:
        errors.append(f"{name}: gateway {v['gateway']} not in {net}")
    if v["ip"] in (v["gateway"], str(net.network_address), str(net.broadcast_address)):
        errors.append(f"{name}: ip {v['ip']} is gateway/network/broadcast of {net}")
    print(f"{name}: {v['ip']}/{v['prefix_length']} net {net.network_address} bcast {net.broadcast_address} "
          f"usable {net.network_address + 1}-{net.broadcast_address - 1}")

if errors:
    print("\n".join("FAIL " + e for e in errors))
    sys.exit(1)
print(f"OK {len(ipam['ipam_prefixes'])} prefixes, {len(ipam['ipam_hosts'])} hosts, {len(vms)} VMs")
