#!/usr/bin/env bash
# Run any command with Keeper secrets injected, from the repo root, on GAS-AUTOCTLR.
#   scripts/run.sh ansible-playbook playbooks/00_preflight.yml
#   scripts/run.sh ansible-playbook playbooks/40_zabbix_agent2_windows.yml --limit GAS-HPV013 --check --diff
#   scripts/run.sh tofu -chdir=tofu plan -var 'vm_names=["GAS-NBX01"]' -out=nbx01.tfplan
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ "$(hostname -s | tr '[:lower:]' '[:upper:]')" != "GAS-AUTOCTLR" && "${GAS_ALLOW_OTHER_HOST:-}" != "1" ]]; then
  echo "Refusing: this repo runs on GAS-AUTOCTLR (set GAS_ALLOW_OTHER_HOST=1 to override)." >&2
  exit 2
fi

VENV="${GAS_VENV:-$HOME/netops/.venv}"
[[ -f "$VENV/bin/activate" ]] || { echo "venv not found: $VENV" >&2; exit 2; }
# shellcheck disable=SC1091
source "$VENV/bin/activate"

[[ -f env/keeper.env ]] || { echo "env/keeper.env missing - copy env/keeper.env.example and fill Keeper UIDs" >&2; exit 2; }
set -a
# shellcheck disable=SC1091
source env/keeper.env
set +a

command -v ksm >/dev/null || { echo "ksm CLI not on PATH in $VENV" >&2; exit 2; }
exec ksm exec -- "$@"
