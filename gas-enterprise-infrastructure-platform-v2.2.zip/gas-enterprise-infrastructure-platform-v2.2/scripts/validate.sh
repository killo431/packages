#!/usr/bin/env bash
# Offline checks only - no host is contacted. Exit non-zero on any failure. Nothing is "simulated".
set -uo pipefail
cd "$(dirname "$0")/.."
rc=0
step() { echo; echo "== $*"; }
run()  { "$@" || { echo "FAIL: $*"; rc=1; }; }

step "IPAM / subnet math";      run python3 scripts/check_ipam.py
step "yamllint";                run yamllint -s .
step "ansible syntax-check"
for p in playbooks/*.yml; do run ansible-playbook --syntax-check "$p" >/dev/null; done
if command -v ansible-lint >/dev/null; then step "ansible-lint"; run ansible-lint -q playbooks/; fi
step "ASCII-only PowerShell";   run bash -c '! grep -nP "[^\x00-\x7F]" playbooks/files/zabbix/*.ps1 scripts/atera/*.ps1'
PWSH="$(command -v pwsh || true)"
if [[ -n "$PWSH" ]]; then
  step "PowerShell parse"
  for f in playbooks/files/zabbix/*.ps1 scripts/atera/*.ps1; do
    run "$PWSH" -NoProfile -Command "\$e=\$null; [void][System.Management.Automation.Language.Parser]::ParseFile('$PWD/$f',[ref]\$null,[ref]\$e); if (\$e) { \$e | ForEach-Object { \$_.Message }; exit 1 }"
  done
fi
step "No secrets committed"
run bash -c '! grep -rnE "(P@ssw0rd|AdminMaster|0123456789abcdef0123|mock-graylog-token|BEGIN (RSA|OPENSSH) PRIVATE)" --exclude-dir=.git --exclude-dir=collections --exclude-dir=docs --exclude=validate.sh .'
if command -v tofu >/dev/null; then
  step "tofu fmt";              run tofu -chdir=tofu fmt -check -recursive
  if [[ -d tofu/.terraform ]]; then
    step "tofu validate"
    run env TF_VAR_state_passphrase="${TF_VAR_state_passphrase:-validate-only-0000}" TF_VAR_hyperv_user=x TF_VAR_hyperv_password=x tofu -chdir=tofu validate
  else
    echo "skip tofu validate (run 'tofu -chdir=tofu init' first)"
  fi
fi
command -v shellcheck >/dev/null && { step "shellcheck"; run shellcheck scripts/*.sh; }
echo; [[ $rc -eq 0 ]] && echo "ALL CHECKS PASSED" || echo "CHECKS FAILED"
exit $rc
