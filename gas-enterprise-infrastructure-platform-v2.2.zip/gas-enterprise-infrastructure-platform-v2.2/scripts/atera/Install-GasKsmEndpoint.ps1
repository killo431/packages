# Install-GasKsmEndpoint.ps1
# Purpose : Install Keeper Secrets Manager CLI on a Windows endpoint and store its client config
#           in an ACL-locked keeper.ini readable only by SYSTEM and local Administrators.
#           Atera "Run as System" scripts can then call ksm; standard users cannot read the config.
# Replaces: the Machine-scope KSM_CONFIG environment variable approach (readable by every user).
# Run as  : Atera > Run Script > As System. Windows PowerShell 5.1. ASCII only. No parameters.
# Inputs  : Atera script variable {[KSM_CONFIG_BASE64]} (pre-bound config from Keeper Commander).
# Output  : C:\scripts\ksm-endpoint-install.log (never contains the config).
# Changes : installs KSM CLI, writes C:\ProgramData\Keeper\ksm\keeper.ini, sets Machine env vars
#           KSM_INI_DIR and KSM_CACHE_DIR (paths only), removes any Machine KSM_CONFIG variable.
# Rollback: Test-GasKsmEndpoint.ps1 shows state; to remove: uninstall KSM CLI, delete
#           C:\ProgramData\Keeper\ksm, clear KSM_INI_DIR / KSM_CACHE_DIR, revoke the client device in Keeper.
# Randy Derego - 2026-10-29

$ErrorActionPreference = 'Stop'

# ---- Settings (<FILL-IN> values must be set before use) -------------------------------------
$PackageShare   = '\\GAS-FIL004\Packages'
$KsmInstaller   = '<FILL-IN installer filename on the Packages share>'
$KsmInstallArgs = '<FILL-IN silent install switches>'
$KsmExe         = '<FILL-IN full path to ksm.exe after install>'
$KsmDir         = 'C:\ProgramData\Keeper\ksm'
$IniFile        = Join-Path $KsmDir 'keeper.ini'
$LogDir         = 'C:\scripts'
$LogFile        = Join-Path $LogDir 'ksm-endpoint-install.log'
$SidSystem      = 'S-1-5-18'
$SidAdmins      = 'S-1-5-32-544'
$Config         = '{[KSM_CONFIG_BASE64]}'
# --------------------------------------------------------------------------------------------

function Write-Log([string]$Message) {
    $line = '{0} {1} {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $env:COMPUTERNAME, $Message
    Add-Content -Path $LogFile -Value $line
    Write-Output $line
}

if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory | Out-Null }

try {
    # 1. Guards
    if ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne $SidSystem) {
        throw 'Must run as SYSTEM (Atera: Run as System).'
    }
    foreach ($v in @($KsmInstaller, $KsmInstallArgs, $KsmExe)) {
        if ($v -like '<FILL-IN*') { throw 'Script settings still contain <FILL-IN> values.' }
    }
    if ([string]::IsNullOrWhiteSpace($Config) -or $Config.StartsWith('{[')) {
        throw 'Atera variable KSM_CONFIG_BASE64 was not substituted.'
    }

    # 2. Install KSM CLI from \\GAS-FIL004\Packages (read access for Domain Computers required)
    if (-not (Test-Path $KsmExe)) {
        $src = Join-Path $PackageShare $KsmInstaller
        $tmp = Join-Path $env:TEMP $KsmInstaller
        Copy-Item -Path $src -Destination $tmp -Force
        $p = Start-Process -FilePath $tmp -ArgumentList $KsmInstallArgs -Wait -PassThru
        Remove-Item -Path $tmp -Force
        if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 3010) { throw ('KSM CLI installer exit code ' + $p.ExitCode) }
        if (-not (Test-Path $KsmExe)) { throw ('ksm.exe not found at ' + $KsmExe + ' after install') }
        Write-Log ('KSM CLI installed (exit ' + $p.ExitCode + ')')
    } else {
        Write-Log 'KSM CLI already installed'
    }

    # 3. Locked directory first, so the config is never written into an open ACL
    if (-not (Test-Path $KsmDir)) { New-Item -Path $KsmDir -ItemType Directory -Force | Out-Null }
    & icacls.exe $KsmDir /inheritance:r /grant:r ('*' + $SidSystem + ':(OI)(CI)F') ('*' + $SidAdmins + ':(OI)(CI)F') | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'icacls failed on ' + $KsmDir }

    # 4. Import config into keeper.ini (replaces any previous file - this is also the rotation path)
    if (Test-Path $IniFile) { Remove-Item -Path $IniFile -Force }
    & $KsmExe profile import --output-file $IniFile $Config | Out-Null
    if ($LASTEXITCODE -ne 0) { throw ('ksm profile import failed, exit ' + $LASTEXITCODE) }
    Remove-Variable -Name Config -Scope Script -ErrorAction SilentlyContinue

    # 5. Enforce and verify the file ACL: SYSTEM + Administrators only, no inheritance
    & icacls.exe $IniFile /inheritance:r /grant:r ('*' + $SidSystem + ':F') ('*' + $SidAdmins + ':F') | Out-Null
    $acl = Get-Acl -Path $IniFile
    $extra = @($acl.Access | ForEach-Object {
        $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
    } | Where-Object { $_ -ne $SidSystem -and $_ -ne $SidAdmins })
    if ($extra.Count -gt 0) { throw ('Unexpected ACEs on keeper.ini: ' + ($extra -join ',')) }

    # 6. Machine env vars hold PATHS only; remove the old secret-bearing variable if present
    [Environment]::SetEnvironmentVariable('KSM_INI_DIR', $KsmDir, 'Machine')
    [Environment]::SetEnvironmentVariable('KSM_CACHE_DIR', $KsmDir, 'Machine')
    if ([Environment]::GetEnvironmentVariable('KSM_CONFIG', 'Machine')) {
        [Environment]::SetEnvironmentVariable('KSM_CONFIG', $null, 'Machine')
        Write-Log 'Removed legacy Machine KSM_CONFIG variable - revoke that client device in Keeper'
    }

    # 7. Prove it works (output discarded - it contains record titles)
    & $KsmExe --ini-file $IniFile secret list | Out-Null
    if ($LASTEXITCODE -ne 0) { throw ('ksm secret list failed, exit ' + $LASTEXITCODE) }

    Write-Log 'OK: keeper.ini locked to SYSTEM + Administrators, KSM reachable'
    exit 0
} catch {
    Write-Log ('FAILED: ' + $_.Exception.Message)
    exit 1
}
