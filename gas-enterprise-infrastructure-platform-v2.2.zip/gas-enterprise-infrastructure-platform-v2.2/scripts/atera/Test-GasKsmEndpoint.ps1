# Test-GasKsmEndpoint.ps1
# Purpose : Read-only audit of the KSM endpoint deployment. Safe to schedule in Atera.
# Run as  : Atera > Run as System. Windows PowerShell 5.1. ASCII only. No parameters. Read-only.
# Output  : C:\scripts\ksm-endpoint-audit.csv (one row appended per run) + one summary line for Atera.
# Checks  : CLI present, keeper.ini present, ACL = SYSTEM + Administrators only, no Machine KSM_CONFIG,
#           KSM_INI_DIR set, live fetch works, members of local Administrators (who can read the config).
# Randy Derego - 2026-10-29

$ErrorActionPreference = 'Stop'

$KsmExe    = '<FILL-IN full path to ksm.exe>'
$KsmDir    = 'C:\ProgramData\Keeper\ksm'
$IniFile   = Join-Path $KsmDir 'keeper.ini'
$OutDir    = 'C:\scripts'
$OutFile   = Join-Path $OutDir 'ksm-endpoint-audit.csv'
$SidSystem = 'S-1-5-18'
$SidAdmins = 'S-1-5-32-544'

if (-not (Test-Path $OutDir)) { New-Item -Path $OutDir -ItemType Directory | Out-Null }

$cliOk = (Test-Path $KsmExe)
$iniOk = (Test-Path $IniFile)

$extraAces = ''
$aclOk = $false
if ($iniOk) {
    $acl = Get-Acl -Path $IniFile
    $extra = @($acl.Access | ForEach-Object {
        try { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
        catch { [string]$_.IdentityReference }
    } | Where-Object { $_ -ne $SidSystem -and $_ -ne $SidAdmins })
    $extraAces = ($extra -join ';')
    $aclOk = ($extra.Count -eq 0) -and $acl.AreAccessRulesProtected
}

$machineConfig = [bool][Environment]::GetEnvironmentVariable('KSM_CONFIG', 'Machine')
$iniDirSet = ([Environment]::GetEnvironmentVariable('KSM_INI_DIR', 'Machine') -eq $KsmDir)

$fetchOk = $false
if ($cliOk -and $iniOk) {
    & $KsmExe --ini-file $IniFile secret list 2>$null | Out-Null
    $fetchOk = ($LASTEXITCODE -eq 0)
}

# Everyone in local Administrators can read keeper.ini. Flatten to plain strings for CSV.
$admins = ''
try {
    $admins = (@(Get-LocalGroupMember -SID $SidAdmins | ForEach-Object { [string]$_.Name }) -join ';')
} catch {
    $admins = 'UNKNOWN'
}

$row = [pscustomobject]@{
    Timestamp           = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    Computer            = [string]$env:COMPUTERNAME
    KsmCliPresent       = [string]$cliOk
    KeeperIniPresent    = [string]$iniOk
    KeeperIniAclLocked  = [string]$aclOk
    ExtraAces           = [string]$extraAces
    MachineKsmConfigSet = [string]$machineConfig
    KsmIniDirSet        = [string]$iniDirSet
    LiveFetchOk         = [string]$fetchOk
    LocalAdministrators = [string]$admins
}
$row | Export-Csv -Path $OutFile -NoTypeInformation -Append

$pass = $cliOk -and $iniOk -and $aclOk -and (-not $machineConfig) -and $iniDirSet -and $fetchOk
Write-Output ('{0} KSM {1} cli={2} ini={3} acl={4} legacyEnv={5} fetch={6} admins={7}' -f `
    $env:COMPUTERNAME, ($(if ($pass) { 'PASS' } else { 'FAIL' })), $cliOk, $iniOk, $aclOk, $machineConfig, $fetchOk, $admins)
if ($pass) { exit 0 } else { exit 1 }
