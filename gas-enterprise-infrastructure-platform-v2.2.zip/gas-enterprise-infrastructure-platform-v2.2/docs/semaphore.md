# Semaphore UI - runner for this repo (replaces AWX)

Randy Derego - 2026-10-29

> **Production Impact:** new service on GAS-AUTOCTLR. Anyone with run rights on a template can change the hosts that template targets, so access, approvals and templates below are part of the change control, not optional.

## Decision

Semaphore UI is the job runner/UI for Ansible and OpenTofu. It replaces AWX. Consequence: **K3s is no longer needed** (the record scoped single-node K3s to AWX only), so one layer drops out of the stack. Ansible and OpenTofu stay on GAS-AUTOCTLR; Semaphore calls the same binaries in the same venv, so CLI runs and Semaphore runs behave the same.

Log in the tracker: "AWX + K3s replaced by Semaphore UI" (decision), and close any AWX/K3s build items.

## Placement and runtime

| Item | Value |
|---|---|
| Host | GAS-AUTOCTLR (172.17.6.26) `<FILL-IN>` confirm - the data sheet shows HTTPS 443 open there; if that is Semaphore already, record its version |
| Install | Native package + systemd, service user `semaphore`. No Docker, no K3s |
| Version | `<FILL-IN>` pin; record it here |
| Database | `<FILL-IN>` BoltDB (single node, file) or PostgreSQL. Do not reuse the Zabbix PostgreSQL on GAS-ZBX01 |
| Listen | Local only (127.0.0.1:3000) behind TLS on 443 `<FILL-IN>` terminator/cert; never 3000 on all interfaces |
| TLS cert | `<FILL-IN>` (internal CA GAS-CA01 is proposed, not built) |
| Toolchain | `<FILL-IN>` shared venv path readable by `semaphore` (ansible-core, pywinrm[kerberos], collections, ksm) + `tofu` on PATH, `/etc/krb5.conf` per docs/krb5.conf.example |

## Secrets

- Semaphore gets **its own KSM client device** (own `keeper.ini`, owner `semaphore`, mode 0600) so Keeper's audit log separates Semaphore runs from Randy's CLI runs and either can be revoked alone.
- The service starts under `ksm exec` (`docs/semaphore/semaphore.service`). `ksm exec` resolves the `keeper://` notation in `/etc/gas/semaphore/keeper.env` (same variable names as `env/keeper.env`), so playbooks and tofu read the same environment variables they read from the CLI. Nothing is copied into Semaphore's key store except the repository access key.
- Rotation of a Keeper secret takes effect on `systemctl restart semaphore`.
- `/proc/<pid>/environ` of the service is readable by root and `semaphore` only.

## Authentication

- LDAP to AD over LDAPS 636 (GAS-ADDS004) with bind account `svc-platform-ldap` (exists in OU=ServAccounts); bind password from Keeper via the service environment.
- Restrict login to an AD group `<FILL-IN>` (e.g. GAS-Automation-Operators). Admin role to Randy only.
- One local break-glass admin, password in Keeper, not used day to day.
- Exact config keys depend on the installed version: `<FILL-IN>` from Semaphore's docs for that version.

## Project layout in Semaphore

| Object | Setting |
|---|---|
| Repository | Azure DevOps Repos URL of this repo `<FILL-IN>`, branch `main`, access key = ADO SSH key or PAT (only secret stored in Semaphore) |
| Inventory | File: `inventory/hosts.yml` |
| Environment | Empty extra vars; secrets come from the service environment |

Templates (one per playbook). Every changing template runs with a **required `--limit`** supplied at launch (`<FILL-IN>` the version's field for limit / CLI args) and has a paired `(check)` template with `--check --diff`:

| Template | Playbook / command | Schedule allowed |
|---|---|---|
| 00 Preflight | playbooks/00_preflight.yml | Yes (daily) - read-only |
| 10 WinRM audit | playbooks/10_winrm_audit.yml | Yes (weekly) - read-only |
| 20 Stage media | playbooks/20_stage_media.yml | No |
| 30 Build seed ISO | playbooks/30_build_seed_iso.yml (`-e vm_names=`) | No |
| 35 Tofu plan | `tofu -chdir=tofu plan -var vm_names=[...] -out=...` | No |
| 36 Tofu apply | apply of the reviewed plan only | No, and run only under an approved CR |
| 40 Zabbix agent | playbooks/40_zabbix_agent2_windows.yml (`-e zabbix_psk_phase=`) | No |
| 50 / 60 / 61 / 70 / 80 | matching playbooks | No |

No template runs the old auto-heal / fleet-bootstrap / KSM-endpoint flows; endpoint KSM stays in Atera (docs/ksm-endpoint-design.md).

## Monitoring and backup

- Zabbix web check on the Semaphore URL `<FILL-IN>` (health endpoint per version) -> JSM on failure.
- Back up Semaphore config + database to `\\gas-fil004\FileShare\Backup\` with the controller (R-002 / R-004).

## Rollback

`systemctl disable --now semaphore`; revoke Semaphore's KSM client device; CLI path (`scripts/run.sh`) keeps working unchanged.
