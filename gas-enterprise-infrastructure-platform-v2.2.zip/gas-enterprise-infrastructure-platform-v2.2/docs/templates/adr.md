# ADR <YYYY-MM-DD>: <decision title>
Randy Derego | Workflow W6 | Status: proposed | accepted | rejected | superseded by <ADR>

## Context (risk ID or gap)
## Decision
## Replaces (one tool per layer)
## Alternatives considered
## Smallest testable version
## Consequences
