# Quote / BOM: <slug>
Randy Derego - <YYYY-MM-DD> | Workflow W2 | Revision: <n>

| # | Part | Model / SKU | Qty | Unit price | Line total | Source |
|---|---|---|---|---|---|---|
|   |      |             |     | Estimated - pending vendor confirmation | | |

**Total:** <sum shown> 

## Compatibility check
| Check | Result |
|---|---|
| Port speeds / transceivers | |
| Form factor / rails / power | |
| Firmware / OS support | |

## Revision log (what changed, totals before/after)
