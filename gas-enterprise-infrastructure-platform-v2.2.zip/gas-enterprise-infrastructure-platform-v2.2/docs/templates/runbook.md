# Runbook: <name>
Randy Derego - <YYYY-MM-DD> | Owner: <FILL-IN> | CR: <id> | Jira: <id>

> **Production Impact:** <...>

## Prerequisites
| Input | Value |
|---|---|
| <name> | <FILL-IN> |

## Steps
| # | Command / action | Expected result | If it fails |
|---|---|---|---|
| 1 | `scripts/run.sh ansible-playbook ... --limit <host> --check --diff` | no unexpected changes | stop, open incident note |

## Verification checklist
## Troubleshooting
| Symptom | Cause | Fix |
|---|---|---|
## Rollback
## Escalation
## History
| Date | Change | By |
|---|---|---|
