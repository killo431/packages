# Incident <YYYY-MM-DD> <slug>
Randy Derego | Workflow W3 | Evidence copied to: <working dir> (originals untouched)

## Symptom (what, since when, who is affected)
## Evidence
| Source | Time | Fact |
|---|---|---|
## Most likely cause (confidence: high/med/low)
## Ruled out
| Hypothesis | How ruled out |
|---|---|
## Next commands (read-only first)
| Command | Expected | Run by |
|---|---|---|
## Fix -> CR + runbook (W1 gates 5-6)
