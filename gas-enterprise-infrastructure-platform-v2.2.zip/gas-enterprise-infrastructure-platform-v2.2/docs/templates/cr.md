# CR-<YYYY>-<AREA>-<NNN>: <title>
Randy Derego - <YYYY-MM-DD> | Workflow W1 gate 5 | Jira: <FILL-IN>

| Field | Value |
|---|---|
| Systems | GAS-... |
| Risk reduced | R-0xx (score) |
| Window | <FILL-IN> (quarterly window: first Sunday of the quarter for OS restarts) |
| Approver | <FILL-IN> |

> **Production Impact:** <what users/services notice, duration, reboot yes/no>

## Change
## Test (check mode / pilot)
## Verification
## Rollback (trigger, steps, time to restore)
## Communication
