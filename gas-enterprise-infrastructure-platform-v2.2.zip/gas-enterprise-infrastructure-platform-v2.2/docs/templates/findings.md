# <Project> - Findings
Randy Derego - <YYYY-MM-DD> | Workflow W1 gate 2 | Discovery: 01-discovery.md

## Conflicts (request / record / action)
| Item | Request says | Record says | Action |
|---|---|---|---|

## Findings
| ID | Finding | Evidence (command/output) | Blast radius | Risk ID or "no 12+ risk - defer" | Recommendation |
|---|---|---|---|---|---|

## Out of scope / deferred

## Assumptions | Risks | Open items (<FILL-IN>) | Next gate
