# PCI remediation group: <root cause>
Randy Derego - <YYYY-MM-DD> | Workflow W4 | Scan: <source/date>

| Finding / plugin | Severity | Hosts (count) | PCI req |
|---|---|---|---|

## Detection first (read-only script, PS 5.1 standard) - proves current use before anything is disabled
## Remediation runbook -> runbooks/<name>.md
## Exec sign-off outline (handoff: Claude .docx)
## Re-scan evidence
