# quotes

One folder or file per item. Start from docs/templates/. See .cursor/rules/80-workflows.mdc.
