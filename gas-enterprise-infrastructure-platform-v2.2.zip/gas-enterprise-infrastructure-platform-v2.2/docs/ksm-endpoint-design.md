# KSM on Windows endpoints - design

Randy Derego - 2026-10-29. Source: "Re: Notes KSM" (2026-10-29). Behavior below was checked against Keeper's
KSM CLI source (GitHub, CLI 1.5.0): `KSM_INI_DIR`, `KSM_CACHE_DIR`, `ksm profile import --output-file`,
and the CLI's own icacls lock-down of keeper.ini. Confirm on the version you install.

> **Production Impact:** installs the KSM CLI and a locked config file on each targeted endpoint via Atera (as SYSTEM). No reboot, no user-visible change. Pilot on 5 endpoints in one site before the fleet.

## Requirement (as stated)

The KSM config is locked behind Administrator, usable only by Atera scripts and Ansible/OpenTofu processes, and encrypted.

## Why the Machine environment variable does not meet it

| Requirement | `KSM_CONFIG` as a Machine env var | Locked keeper.ini (this design) |
|---|---|---|
| Admin-only | No. Machine variables live in `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment`, which Users can read, and every process (each user's Explorer, browser, Office macros) inherits the value. `$env:KSM_CONFIG` works for a standard user. | Yes. File ACL: SYSTEM + Administrators, inheritance removed. A standard user gets Access Denied. |
| Encrypted | No. Base64 is encoding. Decoded it is JSON with the client private key and app key. | At rest it is still a plain file; protection is the ACL. Same as the CLI's own default. |
| Only Atera / Ansible / Tofu | No. Any process on the box. | Atera runs as SYSTEM: yes. Admin sessions: yes. Standard users: no. |
| Keeper's own guidance | The CLI prints a warning that `KSM_CONFIG` bypasses keyring integrity checks. | Normal CLI path. |

Ansible and OpenTofu never need KSM on an endpoint. They run on GAS-AUTOCTLR, resolve secrets there (`ksm exec`), and push only what the task needs over WinRM. The endpoint copy exists for Atera scripts only.

## Design

1. **Keeper application scoped to Atera scripts.** New KSM application (`<FILL-IN name>`) with read-only access to one shared folder that holds only the secrets Atera scripts need. Never share the infrastructure/controller folders (svc-tofu-hyperv, svc-ansible-winrm, Zabbix API, state passphrase) with it.
2. **One client device per site, not one for 500.** ADC, EP1, EP2, PH, VN each get their own pre-bound config (`secrets-manager client add --app <app> --config-init b64`). Revoking one site does not break the others, and Keeper's audit shows which site pulled what.
3. **`--unlock-ip`:** needed only if endpoints reach Keeper from changing public IPs (VPN users, multiple ISPs). Site desktops behind a fixed NAT can stay IP-locked. `<FILL-IN>` per site.
4. **Delivery:** `scripts/atera/Install-GasKsmEndpoint.ps1`, Atera "Run as System", variable `{[KSM_CONFIG_BASE64]}` per site. It installs the CLI from `\\GAS-FIL004\Packages`, creates `C:\ProgramData\Keeper\ksm` locked to SYSTEM + Administrators *before* writing anything, imports the config into `keeper.ini`, verifies the ACL, sets `KSM_INI_DIR` / `KSM_CACHE_DIR` (paths only), removes any legacy Machine `KSM_CONFIG`, and tests a fetch.
5. **Use in Atera scripts:** `& '<ksm.exe>' secret notation 'keeper://<UID>/field/password'` (KSM_INI_DIR finds the config). `--cache` keeps working offline; the cache file sits in the same locked folder.
6. **Audit:** `scripts/atera/Test-GasKsmEndpoint.ps1`, read-only, schedulable. Appends to `C:\scripts\ksm-endpoint-audit.csv` and lists local Administrators members.
7. **Rotation:** create a new client device for the site, update the Atera variable, rerun the installer (it replaces keeper.ini), then revoke the old device.

## Dropped from the notes

| Item | Reason |
|---|---|
| Machine `KSM_CONFIG` | Readable by all users; replaced by the locked file. |
| winget install | winget is a per-user AppX package and is usually not resolvable as SYSTEM, which is how Atera runs. Install from `\\GAS-FIL004\Packages` instead. |
| pip3 fallback | Python is not on the desktop baseline. |
| SecretManagement.Keeper + SecretStore | Needs PowerShell 7 (desktops default to 5.1), SecretStore is per-user and prompts for a password under SYSTEM unless reconfigured. The CLI covers the use case. |

## Residual risks

- **Local admins can read keeper.ini.** That is inherent to "locked behind Administrator". If users are local admins on their own desktops, or the local Administrator password is shared (LAPS not deployed, R-008), the lock is weak. The audit script reports Administrators membership per machine.
- **Atera holds the base64 config** as a script variable. Anyone with Atera script-edit rights can read it, and Atera is SaaS. Limit Atera script permissions; PCI note: confirm whether any target desktops are in CDE scope (EP collections VLANs).
- **Command-line auditing.** `ksm profile import` takes the config as an argument. If process-creation auditing with command line (event 4688 + "Include command line") is enabled by GPO, the config lands in the Security log. `<FILL-IN>` check the GPO; the Graylog collector config deliberately excludes 4688.
- **Atera script staging.** Atera writes the substituted script to disk to run it. `<FILL-IN>` confirm where and that it is deleted after the run.
- **Scope.** The record scopes current work to infrastructure, servers and networks. This is a desktop rollout; it is justified under the risk gate only if Atera scripts currently hold plaintext credentials (R-006, score 12). `<FILL-IN>` confirm which scripts and secrets.

## Rollout

| Step | Target | Gate |
|---|---|---|
| 1 | 5 ADC desktops | Audit = PASS on all 5; standard user gets Access Denied on keeper.ini |
| 2 | ADC remaining | No failed Atera runs for 1 week |
| 3 | EP1, EP2 | Per-site config; IP lock decision per site |
| 4 | PH, VN | Same |

## Rollback

Atera: uninstall KSM CLI, delete `C:\ProgramData\Keeper\ksm`, clear `KSM_INI_DIR` and `KSM_CACHE_DIR`; in Keeper revoke the site's client device (immediate, all endpoints of that site stop resolving).
