# Firewall flows needed by this repo (FMC ACP "ADC-Global")

Objects, not raw IPs. Same-segment flows (both ends in 172.17.6.0/23) do not cross the FTD and need no rule.

| # | Source object | Destination object | Port/proto | Purpose | Crosses FTD? | Rule |
|---|---|---|---|---|---|---|
| 1 | GAS-AUTOCTLR (172.17.6.26/32) | GAS-HPV004 (172.17.1.42/32), GAS-HPV009 (172.17.2.60/32) | TCP 5986 | WinRM HTTPS (Ansible) | Yes: ADC-Services -> Inside-LAN1 / Inside-LAN2 | `<FILL-IN>` new or existing |
| 2 | GAS-AUTOCTLR | GAS-HPV010/011/012/013/014 (172.17.6.10-.14) | TCP 5986 | WinRM / OpenTofu | No | - |
| 3 | GAS-AUTOCTLR | GAS-ADDS004 (172.17.6.33/32) | TCP/UDP 88, TCP/UDP 53 | Kerberos, DNS | No | - |
| 4 | GAS-AUTOCTLR | GAS-ZBX01 (172.17.6.24/32) | TCP 443 `<FILL-IN>` | Zabbix API | No | - |
| 5 | GAS-ZBX01 | Hyper-V hosts | TCP 10050 | Passive checks | Yes for HPV004/HPV009 | `<FILL-IN>` |
| 6 | Hyper-V hosts | GAS-ZBX01 | TCP 10051 | Active checks | Yes for HPV004/HPV009 | `<FILL-IN>` |
| 7 | Windows targets | GAS-FIL004 (172.17.6.36/32) | TCP 445 | \\GAS-FIL004\ISO, \\GAS-FIL004\Packages | HPV004/HPV009 may use FIL004's .1.56/.2.56 legs - confirm which IP gas-fil004 resolves to | `<FILL-IN>` |
| 8 | Windows targets | GAS-GLG01 (172.17.6.25/32) | TCP 9000 (sidecar API), TCP `<FILL-IN>` (Beats, TLS) | Graylog sidecar | Yes for non-VLAN-6 hosts (PDF: "requires inter-zone ACL") | `<FILL-IN>` |
| 9 | GAS-AUTOCTLR | GAS-NBX01 (172.17.6.23/32) | TCP 443 | NetBox API | No | - |
| 10 | Admin VPN pool (172.17.3.0/24) | GAS-AUTOCTLR (172.17.6.26/32) | TCP 443 | Semaphore UI (HTTPS only; 3000 stays on localhost) | Yes | `<FILL-IN>` |
| 11 | GAS-AUTOCTLR | GAS-ADDS004 (172.17.6.33/32) | TCP 636 | Semaphore LDAPS bind (svc-platform-ldap) | No | - |
| 12 | GAS-AUTOCTLR, Windows endpoints | Keeper cloud `<FILL-IN region hostnames>` | TCP 443 | KSM API (outbound, all sites) | Yes, outside zone | `<FILL-IN>` per site |
| 13 | Windows endpoints (computer accounts) | GAS-FIL004 | TCP 445 | KSM CLI installer from `\\GAS-FIL004\Packages` (needs Domain Computers read) | Yes for non-VLAN-6 and remote sites (EP over tunnel) | `<FILL-IN>` |

Subnet math for every network referenced:

| CIDR | Network | Broadcast | Usable |
|---|---|---|---|
| 172.17.6.0/23 | 172.17.6.0 | 172.17.7.255 | 172.17.6.1-172.17.7.254 |
| 172.17.1.0/24 | 172.17.1.0 | 172.17.1.255 | 172.17.1.1-172.17.1.254 (gateway .5 act / .6 sby) |
| 172.17.2.0/24 | 172.17.2.0 | 172.17.2.255 | 172.17.2.1-172.17.2.254 (gateway .1 act / .2 sby) |
| 172.17.3.0/24 | 172.17.3.0 | 172.17.3.255 | 172.17.3.1-172.17.3.254 |
| /32 host objects | the host | the host | single address |

No temporary access is requested, so no expiry dates apply.
