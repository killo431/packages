# Review fixes - generated bundle -> v2

Randy Derego - 2026-10-29. Source review: GAS-Platform-Bundle-Review-2026-10-29.md (findings F-01..F-17, conflicts C1..C24).

## Findings

| ID | Finding | Status in v2 | Where |
|---|---|---|---|
| F-01 | Fabricated environment facts | Fixed: all facts rebuilt from the data sheet PDF + record; unknowns are null `<FILL-IN>`; fact generator removed | `data/*.yml` |
| F-02 | Fabricated validation reports | Fixed: reports deleted; `scripts/validate.sh` runs real checks only | `scripts/validate.sh` |
| F-03 | Hard-coded credentials | Fixed: none in repo; Keeper notation via `ksm exec`; validate.sh greps for the old strings | `scripts/run.sh`, `env/keeper.env.example` |
| F-04 | `hosts: all` blast radius, firewalls as WinRM hosts | Fixed: inventory holds managed targets only; every changing play needs `--limit`; `planned` group excluded | `inventory/hosts.yml`, `playbooks/` |
| F-05 | Autonomous auto-heal daemon | Removed. Alerting path is Zabbix -> JSM | - |
| F-06 | CredSSP + NTLM + Administrator + cert validation off | Fixed: Kerberos as svc-ansible-winrm, validation on; share access via runas netcredentials_only; audit play reports CredSSP still enabled | `inventory/group_vars/windows.yml`, `playbooks/10_winrm_audit.yml` |
| F-07 | KSM_CONFIG on 500 workstations | Revised 2026-10-29 per Randy: endpoint KSM is for Atera scripts. Rebuilt as a locked keeper.ini (SYSTEM + Administrators), per-site client devices, scoped read-only Keeper app; Machine env var dropped because Users can read it | `docs/ksm-endpoint-design.md`, `scripts/atera/` |
| F-08 | Duplicate tools | Revised 2026-10-29 per Randy: **Semaphore UI replaces AWX** (K3s dropped with it), installed natively on GAS-AUTOCTLR under `ksm exec`. Still removed: OpenSpec UI, Packer, auto-heal, Docker runner. Atera and Bitdefender kept as gated installers | `docs/semaphore.md` |
| F-09 | Broken OpenTofu | Rebuilt: ISO + autoinstall seed (same method as gas-platform-tofu), VLAN 6 access, G:\VMs-Dev, GAS- names, encrypted state, preconditions for every `<FILL-IN>`; `tofu validate` passes and a plan was exercised with test values | `tofu/` |
| F-10 | Differencing disks off a locked master | Removed: each VM gets its own dynamic VHDX | `tofu/modules/ubuntu_vm` |
| F-11 | Dual SSH auth everywhere | Fixed: Linux only, key-only default, key+password opt-in, `sshd -t` with auto-revert; Windows sshd untouched | `playbooks/70_ssh_hardening_linux.yml` |
| F-12 | Winlogbeat: 4 event IDs, plaintext, static file | Fixed: collector config moved to Graylog with PCI 10.2 event set and TLS; sidecar installed properly, token file ACL'd | `docs/graylog-winlogbeat-collector.yml`, `playbooks/50_*` |
| F-13 | One fleet-wide Zabbix PSK, agent never installed | Fixed: per-host 256-bit PSK, kept on rerun, ACL'd; two-phase cutover via API; LLD + checkpoint-age scripts written (PS 5.1, ASCII, read-only) | `playbooks/40_*`, `playbooks/files/zabbix/` |
| F-14 | YAML/XML parse errors, missing task files, `-auto-approve` | Fixed: all playbooks pass syntax-check and ansible-lint; autounattend parses; tofu runs plan -> saved plan -> apply | - |
| F-15 | controller_scan.py copied *.psk and AI rule files | Removed | - |
| F-16 | Dockerfile `|| true`, unpinned installs | Removed; requirements pinned to ranges | `requirements.*` |
| F-17 | Dual-DC consensus | Removed | - |

Salvaged: checkpoint > 24h trigger (`docs/zabbix-items.md`), Gen 2 Secure Boot template `MicrosoftUEFICertificateAuthority` for Ubuntu, `checkpoint_type = Production`. Paged LDAP sync deferred until an AD -> NetBox sync is scoped.

## Bundle conflicts C1..C24

All bundle values were dropped; v2 uses the record/PDF values. C6 resolved by the PDF: ADC-Inside-LAN1 gateway is 172.17.1.5 (active) / .6 (standby), not .1.1. C7 resolved: 172.17.4.1/.2 are the FW SQL-zone gateways. C22 (workstation scope) left out of v2. C24: Gen 2 applies to new tofu VMs only; GAS-PVE01 (Gen 1) is untouched.

## New conflicts: data sheet PDF vs record (not resolved - record kept unless noted)

| # | PDF says | Record / check says | Action |
|---|---|---|---|
| P-01 | RAVPN pools aggregate 172.17.253.0/23, range .253.1-.254.254, bcast .254.255 | Invalid boundary: a /23 must start on an even third octet. The /23 holding .253 is 172.17.252.0/23 (net .252.0, bcast .253.255) and does not contain .254.0/24. Smallest covering block is 172.17.252.0/22 (net .252.0, bcast .255.255) | Stored the three record pools separately; correct the data sheet |
| P-02 | GAS-FIL004 platform "File Cluster" | Standalone R740xd file server, no cluster on record | `<FILL-IN>` confirm |
| P-03 | GAS-ADDS004 platform "Hyper-V / ESXi" | No ESXi on record at ADC | `<FILL-IN>` confirm host |
| P-04 | GAS-AUTOCTLR ports SSH 22, HTTPS 443 | No web service on the controller in record (AWX is on K3s, location unconfirmed) | `<FILL-IN>` what listens on 443 |
| P-05 | PH DCs on "Baguio ESXi" | Not on record | Note only |
| P-06 | Public block "default gateway" 207.207.44.108 / .109 | Those are the FW outside addresses; upstream next hop likely .105 | `<FILL-IN>` |
| P-07 | PH 10.88.0.0/16 and VN 10.89.0.0/16 shown as LANs | Aggregates; DC subnets 10.88.12.x / 10.89.10.x have no mask on record | DC `ip_cidr` left null `<FILL-IN>` |
| P-08 | GAS-GLG01 Web 9000, GELF 12201 | Sidecar Winlogbeat needs a Beats input (TLS) | `<FILL-IN>` Beats port |
| P-09 | VLAN IDs only implied by subinterface numbers (po1.10, .20, .4, .16) | Only VLAN 6 is confirmed | Other ADC VLAN IDs null; NetBox seed skips them |

## Removed files

AGENTS.md (autonomous constitution - replaced), AUDIT_REPORT.md, COMPLIANCE_REPORT.md, VALIDATION_REPORT.md, DEPLOYMENT_READINESS.md, CUTOVER_PLAN.md, OPERATIONS_HANDOFF.md, ROADMAP.md, AUTO_REPAIR_AND_UNSTUCK_GUIDE.md, all `*_graph.json` and `*_inventory.json`, environment_profile.json, environment_classification.yml, `.notes/`, `generated_prompts/`, `instructions/` (replaced by README run order), docker-compose.yml, Dockerfile.semaphore-runner, deploy.ps1/.sh, validate.ps1, scripts/controller_scan.py, inventory/hosts.ini, inventory/netbox_inventory.yml (re-add once NBX01 exists, token from env), tofu/graylog.tf, tofu/netbox.tf, tofu/hyperv_windows.tf, playbooks: auto_heal_remediation, deploy_ksm_endpoints, full_fleet_bootstrap, provision_hyperv_vm, run_packer_build, configure_ssh_dual_auth (replaced by 70), winrm_hyperv_setup (replaced by 10), templates: sshd_config_windows, network-config, user-data (replaced by autoinstall), winlogbeat.yml.j2 (moved to Graylog config).

Decisions to log in the tracker:
- Accepted: Semaphore UI replaces AWX; K3s no longer required.
- Accepted with changes: endpoint KSM for Atera scripts, locked keeper.ini, per-site configs.
- Rejected: OpenSpec UI, Packer + differencing masters, auto-heal daemon, Machine-scope KSM_CONFIG, SecretManagement/SecretStore on endpoints, dual-DC consensus.

## Open items (`<FILL-IN>`)

- Package filenames on `\\GAS-FIL004\Packages` (Zabbix agent2 MSI, Graylog sidecar, Atera MSI, Bitdefender) and confirm the Ubuntu ISO name on `\\GAS-FIL004\ISO`.
- svc-ansible-winrm rights: local admin / Hyper-V Administrators on targets; read on both shares.
- HPV013 vSwitch name for VLAN 6; HPV012 vm_root, iso_dir, vSwitch, WinRM HTTPS listener + cert.
- Sizing (vCPU / RAM / OS disk) for GAS-NBX01 and GAS-GLG01.
- Keeper record UIDs for env/keeper.env; netadmin public key path on the controller.
- Zabbix API URL/path; host names in Zabbix match inventory names; Beats input port on GLG01.
- ADC VLAN IDs for subinterfaces .10, .20, .4, .8, .16; PH/VN DC subnet masks.
- FMC rules in docs/firewall-flows.md rows 1, 5-8.
- Data sheet corrections P-01..P-09.
- Semaphore: version, DB (BoltDB vs PostgreSQL), TLS cert/terminator, venv path, AD operator group, whether port 443 on GAS-AUTOCTLR (data sheet) is already Semaphore.
- Endpoint KSM: KSM CLI installer filename + silent switches + ksm.exe path; Keeper app/shared folder name; IP-lock decision per site; which Atera scripts/secrets justify it (R-006); 4688 command-line auditing GPO; Domain Computers read on `\\GAS-FIL004\Packages`; local Administrators membership on desktops (R-008).
