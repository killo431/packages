# Zabbix items for the Hyper-V UserParameters

Create in a GAS template (e.g. `GAS Hyper-V host`) and link to hosts in `GAS/ADC/Hyper-V` (naming per record: `GAS/<site>/<class>`).

| Type | Key | Interval | Notes |
|---|---|---|---|
| Discovery rule | `gas.hyperv.vm.discovery` | 1h | Macros `{#VMNAME}`, `{#VMID}`, `{#VMGEN}`. Keep lost resources 7d. Duplicate `{#VMID}` across hosts = the stale double registrations in the record (36 VMs). |
| Item | `gas.hyperv.checkpoint.maxage.hours` | 1h | Unit `h`. |

| Trigger | Expression | Severity |
|---|---|---|
| Hyper-V checkpoint older than 24h on {HOST.NAME} | `last(/GAS Hyper-V host/gas.hyperv.checkpoint.maxage.hours)>24` | Warning |
| Checkpoint age item unsupported on {HOST.NAME} | `nodata(/GAS Hyper-V host/gas.hyperv.checkpoint.maxage.hours,3h)=1` | Average |

Alert path: existing Zabbix -> JSM webhook (record decision). No auto-remediation.
