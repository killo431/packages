# gas-hyperv-checkpoint-maxage.ps1
# Age in whole hours of the oldest checkpoint on this host (0 if none). Trigger in Zabbix at > 24.
# Windows PowerShell 5.1, ASCII only, read-only, no parameters. Output to stdout for Zabbix.
# Randy Derego - 2026-10-29
$ErrorActionPreference = 'Stop'
try {
    $snaps = @(Get-VM | Get-VMSnapshot)
    if ($snaps.Count -eq 0) { Write-Output 0; exit 0 }
    $oldest = ($snaps | Sort-Object CreationTime | Select-Object -First 1).CreationTime
    Write-Output ([math]::Floor(((Get-Date) - $oldest).TotalHours))
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
