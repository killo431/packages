# gas-hyperv-vm-discovery.ps1
# Zabbix LLD for Hyper-V guests on this host. Windows PowerShell 5.1, ASCII only, read-only, no parameters.
# Output goes to stdout (Zabbix UserParameter contract) instead of C:\scripts - documented deviation.
# On error it writes nothing and exits 1 so the item goes unsupported instead of reporting zero VMs.
# Randy Derego - 2026-10-29
$ErrorActionPreference = 'Stop'
try {
    $rows = @(Get-VM | ForEach-Object {
        [pscustomobject]@{
            '{#VMNAME}'  = [string]$_.Name
            '{#VMID}'    = [string]$_.VMId
            '{#VMGEN}'   = [string]$_.Generation
        }
    })
    ConvertTo-Json -InputObject $rows -Compress
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
